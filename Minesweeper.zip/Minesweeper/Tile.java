package has.edu;

public class Tile {
	String tileBlock;
	public Tile(){
		tileBlock = "X";
	}
	public String getTileBlock(){
		return tileBlock;
	}
	public void setTileBlock(String tile){
		tileBlock = tile;
	}
	public void setTileBlock(int tile){
		if(tile == 0){
			tileBlock = "0";
		}
		else if(tile == 1){
			tileBlock = "1";
		}
		else if(tile == 2){
			tileBlock = "2";
		}
		else if(tile == 3){
			tileBlock = "3";
		}
		else if(tile == 4){
			tileBlock = "4";
		}
		else if(tile == 5){
			tileBlock = "5";
		}
		else if(tile == 6){
			tileBlock = "6";
		}
		else if(tile == 7){
			tileBlock = "7";
		}
		else if(tile == 8){
			tileBlock = "8";
		}
	}
	public String toString(){
		return tileBlock;
	}
}
