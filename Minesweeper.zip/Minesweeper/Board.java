package has.edu;

import java.util.Random;

public class Board {
	Tile[][] board = new Tile[5][5];
	Tile[][] board2 = new Tile[5][5];
	public Board(){
		board = new Tile[5][5];
		for(int x = 0; x < 5; x++){
			for(int y = 0; y < 5; y++){
				Tile tile1 = new Tile();
				board[x][y] = tile1;
				board2[x][y] = tile1;
			}
		}
	}
	public void setRandom(int level){
		Random gen1 = new Random();
		int choice = 0;
		if(level == 1){
			choice = 5;
			System.out.println("You have chosen the beginner level.");
		}
		else if(level == 2){
			choice = 10;
			System.out.println("You have chosen the intermediate level.");
		}
		else if(level == 3){
			choice = 15;
			System.out.println("You have chosen the expert level.");
		}
		else{
			choice = 5;
			System.out.println("You have chosen beginner level by default.");
		}
		int count = 1;
		while(count <= choice){
		for(int x = 0; x < 5; x++){
			for(int y = 0; y < 5; y++){
				int random = gen1.nextInt(2);
				Tile tile1 = new Tile();
				if(board2[x][y].getTileBlock() != "B"){
					if(count <= choice){
						if(random == 0){
							tile1.setTileBlock("X");
						}
						else{
							tile1.setTileBlock("B");
							count++;
						}
					}
					board2[x][y] = tile1;
				}
			}
		}
		}
	}
	public boolean checkBomb(){
		for(int x = 0; x < 5; x++){
			for(int y = 0; y < 5; y++){
				if(board[x][y].getTileBlock() == "B"){
					return false;
				}
			}
		}
		return true;
	}
	public boolean checkSpot(int x, int y){
		if(board[x][y].getTileBlock() == "X" ||
		board2[x][y].getTileBlock() == "B"){
			return true;
		}
		else{
			return false;
		}
	}
	public void checkTile(int x, int y){
		if(board2[x][y].getTileBlock() == "B"){
            board[x][y].setTileBlock("B");
        }
		else{
			int count0 = 0;
			for(int n = x-1; n < x+2; n++){
				for(int m = y-1; m < y+2; m++){
					if(n > -1 && m > -1 && n < 5 && m < 5){
						if(board2[n][m].getTileBlock() == "B"){
							count0++;
						}
					}
				}
			}
			board[x][y].setTileBlock(count0);
	    }
	}
	public void printBoard2(){
		for(int x = 0; x < 5; x++){
			for(int y = 0; y < 5; y++){
				System.out.print(board2[x][y] + " 	");
			}
			System.out.println();
		}
	}
	public String toString(){
		String temp = "";
		for(int x = 0; x < 5; x++){
			for(int y = 0; y < 5; y++){
				temp = temp + board[x][y] + "	";
			}
			temp = temp + "\n";
		}
		temp = temp + "\n";
		/** for(int x = 0; x < 5; x++){
			for(int y = 0; y < 5; y++){
				temp = temp + board2[x][y] + "	";
			}
			temp = temp + "\n";
		} **/
		return temp;
	}
}
