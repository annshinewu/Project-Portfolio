package has.edu;
import java.util.Scanner;

public class Assignment15 {
	public static void main(String[] args) {
		/** 
		int [][]chart = new int[10][10];
		for(int x = 0; x < 10; x++){
			for(int y = 0; y < 10; y++){
				chart[x][y] = (x+1)*(y+1);
				System.out.print(chart[x][y] + "	");
			}
			System.out.println();
		} 
		**/
		Board board1 = new Board();
		Scanner reader = new Scanner(System.in);
		System.out.println("Beginner(5 bombs): 1");
		System.out.println("Intermediate(10 bombs): 2");
		System.out.println("Expert(15 bombs): 3");
		System.out.print("Please enter the level: ");
		int level = Integer.valueOf(reader.nextLine());
		board1.setRandom(level);
		int bombs = 0; 
		if(level == 2){
			bombs = 10;
		}
		else if(level == 3){
			bombs = 15;
		}
		else{
			bombs = 5;
		}
		System.out.println(board1);
		for(int points = 0; points < 25; points++){
			System.out.print("Enter a row: ");
			int row = Integer.valueOf(reader.nextLine());
			System.out.print("Enter a column: ");
			int column = Integer.valueOf(reader.nextLine());
			if(row >= 0 && column >= 0 && row < 5 && column < 5){
				boolean check2 = board1.checkSpot(row, column);
				if (check2 == false){
					points--;
				}
				board1.checkTile(row, column);
				boolean check = board1.checkBomb();
				if(check == false){
					board1.printBoard2();
					System.out.println("GAME OVER");
					if(points <= 0){
						System.out.println("Points: 0");
					}
					else{
						System.out.println("Points: " + points);
					}
					points = 100;
				}
				else{
					System.out.println(board1);
				}
			}
			else{
				System.out.println("That is out of bounds");
				points--;
			}
			if((points+1) == (25 - bombs)){
				System.out.println("YOU WIN!");
				points = 100;
			}
		}
	}
}
