package edu.has;
import java.util.Random;

public class BookShelf {
	private Book one;
	private Book two;
	private Book three;
	private Book four;
	private Book five;
	private int empty;
	private int full;
	public BookShelf(){
		one = new Book();
		two = new Book();
		three = new Book();
		four = new Book();
		five = new Book();
		empty = 0;
		full = 0;
	}
	public BookShelf(String author1, String title1, String author2,
			String title2, String author3, String title3, 
			String author4, String title4, String author5, String title5){
		one = new Book(author1, title1);
		two = new Book(author2, title2);
		three = new Book(author3, title3);
		four= new Book(author4, title4);
		five = new Book(author5, title5);
		empty = 0;
		full = 0;
	}
	/**
	*param: empty
	*@return empty
	*choose a random book, 
	*call the function in book to either take it out, or put it back in
	*check if the shelf is full (counter for full) 
	*check if the shelf is empty (counter for empty) 
	*/
	public void chooseBook(){
		Random randGen = new Random();
		int randomi = randGen.nextInt(5-1+1)+1;
		if(randomi == 1){
			one.swapPlace();
		}
		if(randomi == 2){
			two.swapPlace();
		}
		if(randomi == 3){
			three.swapPlace();
		}
		if(randomi == 4){
			four.swapPlace();
		}
		if(randomi == 5){
			five.swapPlace();
		}
		if(one.getPlace() == true && two.getPlace() == true &&
			three.getPlace() == true && four.getPlace() == true
			&& five.getPlace() == true){
			System.out.println("All books are present");
			full++;
		}
		if(one.getPlace() == false && two.getPlace() == false &&
			three.getPlace() == false && four.getPlace() == false
			&& five.getPlace() == false){
			System.out.println("All books are currently taken out.");
			empty++;
		}
	}
	/**
	*param: empty
	*@return empty
	*prints out all the books in the HAS library
	*/
	public void print1(){
		System.out.println("HAS Library");
		System.out.println("Space 1: " + one);
		System.out.println("Space 2: " + two);
		System.out.println("Space 3: " + three);
		System.out.println("Space 4: " + four);
		System.out.println("Space 5: " + five);
	}
	/**
	*param: empty
	*@return empty
	*prints out information about books
	*/
	public void print2(){
		System.out.println("Book 1 was taken and returned " + 
				one.getIn() + " times.");
		System.out.println("Book 2 was taken and returned " + 
				two.getIn() + " times.");
		System.out.println("Book 3 was taken and returned " + 
				three.getIn() + " times.");
		System.out.println("Book 4 was taken and returned " + 
				four.getIn() + " times.");
		System.out.println("Book 5 was taken and returned " + 
				five.getIn() + " times.");
		System.out.println("Shelf was empty " + empty + " times.");
		System.out.println("Shelf was full " + full + " times.");
	}
}
