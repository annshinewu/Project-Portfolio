package edu.has;

public class Book {
	private String author;
	private String title;
	private boolean place;
	private int in;
	public Book(){
		author = "";
		title = "";
	}
	public Book(String myAuthor, String myTitle){
		author = myAuthor;
		title = myTitle;
		place = true;
	}
	public boolean getPlace(){
		return place;
	}
	public int getIn(){
		return in;
	}
	public String getTitle(){
		return title;
	}
	public String getAuthor(){
		return author;
	}
	public void setTitle(String myTitle){
		title = myTitle;
	}
	public void setAuthor(String myAuthor){
		author = myAuthor;
	}
	/**
	*param: empty
	*@return empty
	*check whether the book is out or in
	*if out --> put back in (add counter)
	*if in --> take out
	*/
	public void swapPlace(){
		if(place == true){
			place = false;
			System.out.println(title + " by " + 
					author + " has been taken out.");
		}
		else{
			place = true;
			in++;
			System.out.println(title + " by " + 
					author + " has been returned.");
		}
	}
	/**
	*param: empty
	*@return title of book by author
	*/
	public String toString(){
		return title + " by " + author;
	}
}
