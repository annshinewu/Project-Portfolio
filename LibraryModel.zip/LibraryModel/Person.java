package edu.has;

public class Person {
	private String name;
	private int age;
	
	public Person(){
		name = "Kerr";
		age = 30;
	}
	public String toString(){
		return name + " is " + age + " years old.";
	}
	public Person isOlder(Person other){
		if(age > other.getAge()){
			return this;
		}
		else{
			return other;
		}
	}
	public static Person isOlder(Person first, Person second){
		if(first.getAge() > second.getAge()){
			return first;
		}
		else{
			return second;
		}
	}
	public int getAge(){
		return age;
	}
	public void setAge(int x){
		age = x;
	}
	public void setName(String n){
		name = n;
	}
}
