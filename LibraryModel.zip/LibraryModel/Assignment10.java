package edu.has;

import java.util.Scanner;

public class Assignment10 {
	public static void main (String[] arges){
		//Person per = new Person();
			//	per.print();
			//System.out.println(per);
			//	Printing the reference
		//Person per3 = new Person();
		//per3.setAge(25);
		//per3.setName("Billy");
			//Person old = per.isOlder(per3);
			//System.out.println(old);
		///Person old2 = per.isOlder(per,per3);
		//System.out.println(old2);
		BookShelf A1 = new BookShelf(
			"Mr.Pohlman","Mans Guide to Mustaches",
			"Mr. Witte", "How to Eat a Guava",
			"Mr. Hildreth", "Punching Meat in the Face",
			"Mr. Witte", "The Art of Googling",
			"Mrs.Kruger", "How to Dance Artistically");
		A1.print1();
		Scanner reader = new Scanner(System.in);
		System.out.print("How many transactions will be made: ");
		int in = Integer.valueOf(reader.nextLine());
		for(int x = 1; x <= in; x++){
			A1.chooseBook();
		}
		A1.print2();
	}
}
